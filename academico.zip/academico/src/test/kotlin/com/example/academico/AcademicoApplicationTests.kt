package com.example.academico

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class AcademicoApplicationTests {

	@Test
	fun contextLoads() {
	}

}
